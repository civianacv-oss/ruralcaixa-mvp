# 📦 Arquivos de Monitoramento — RuralCaixa MVP

Este pacote contém todos os arquivos necessários para implementar o sistema de monitoramento de qualidade da água (amônia/nitrito) no projeto **ruralcaixa-mvp**.

## 📁 Estrutura dos Arquivos

```
ruralcaixa-mvp-files/
├── scripts/
│   ├── monitor_amonia_nitrito.py       # Monitor Python (Linux/Ubuntu)
│   ├── enviar_alertas_whatsapp.py      # WhatsApp Python
│   ├── Monitor-AmoniaaNitrito.ps1      # Monitor PowerShell (Windows)
│   └── Send-AlertasWhatsApp.ps1        # WhatsApp PowerShell
│
├── sql/
│   ├── schema_alertas.sql              # Criar tabelas de alertas
│   └── schema_contatos_imovel.sql      # Criar tabela de contatos
│
├── .github/workflows/
│   ├── alertas-cron.yml                # Workflow com Python (ubuntu-latest)
│   └── alertas-cron-powershell.yml     # Workflow com PowerShell (windows-latest)
│
├── docs/
│   ├── GUIA_IMPLEMENTACAO.md           # Guia geral de implementação
│   ├── SETUP_WHATSAPP.md               # Setup Meta Cloud API
│   └── SETUP_POWERSHELL.md             # Setup PowerShell no GitHub Actions
│
└── README.md                           # Este arquivo
```

## 🚀 Como Usar

### 1️⃣ Copiar para seu Repositório

Copie os arquivos para os locais corretos no seu repositório:

```bash
# Scripts Python
cp scripts/monitor_amonia_nitrito.py ruralcaixa-mvp/scripts/
cp scripts/enviar_alertas_whatsapp.py ruralcaixa-mvp/scripts/

# Scripts PowerShell
cp scripts/Monitor-AmoniaaNitrito.ps1 ruralcaixa-mvp/scripts/
cp scripts/Send-AlertasWhatsApp.ps1 ruralcaixa-mvp/scripts/

# Workflows
cp .github/workflows/alertas-cron.yml ruralcaixa-mvp/.github/workflows/
cp .github/workflows/alertas-cron-powershell.yml ruralcaixa-mvp/.github/workflows/

# SQL
cp sql/*.sql ruralcaixa-mvp/sql/  # ou outro local apropriado
```

### 2️⃣ Executar Scripts SQL

Execute os scripts SQL no seu PostgreSQL:

```bash
psql -U seu_usuario -d seu_banco -f sql/schema_alertas.sql
psql -U seu_usuario -d seu_banco -f sql/schema_contatos_imovel.sql
```

### 3️⃣ Configurar Secrets no GitHub

Adicione em **Settings → Secrets and variables → Actions**:

- `DATABASE_URL` (obrigatório)
- `WHATSAPP_TOKEN` (opcional por enquanto)
- `WHATSAPP_PHONE_ID` (opcional por enquanto)

### 4️⃣ Fazer Commit e Push

```bash
git add scripts/ .github/workflows/ sql/
git commit -m "feat: adicionar monitor de amônia/nitrito com alertas"
git push origin main
```

## 📖 Documentação

Leia os arquivos de documentação para mais detalhes:

- **GUIA_IMPLEMENTACAO.md** — Visão geral e passo a passo
- **SETUP_WHATSAPP.md** — Como configurar Meta Cloud API
- **SETUP_POWERSHELL.md** — Como usar PowerShell no GitHub Actions

## 🎯 Escolha sua Abordagem

### Python (Recomendado para Linux)
- Runner: `ubuntu-latest`
- Setup: ~30s
- Arquivo: `.github/workflows/alertas-cron.yml`

### PowerShell (Recomendado para Windows)
- Runner: `windows-latest`
- Setup: ~60s
- Arquivo: `.github/workflows/alertas-cron-powershell.yml`

## 🔍 Próximos Passos

1. Escolha Python ou PowerShell (ou ambos!)
2. Execute os scripts SQL
3. Configure os secrets no GitHub
4. Teste manualmente rodando o workflow
5. Quando tiver tokens WhatsApp, ative as notificações

## 📞 Dúvidas?

Consulte a documentação nos arquivos `.md` ou verifique os logs do GitHub Actions para debug.

---

**Versão:** 1.0  
**Data:** 2026-06-24  
**Autor:** Manus AI
